<?php include "include/security.php" ?>
<?php $_SESSION['pageName'] = 'blogs' ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php include "include/title.php"; ?>
	<?php include "include/css.php"; ?>
</head>
	
<body>
	<?php include "include/topNav.php"; ?>
	
	<div class="banner1">			
		<div class="w3_agileits_service_banner_info">
			<h2>TSPH Blogs</h2>
		</div>
	</div>
	
	<div class="col-md-12">
		<div style="height:50px;"></div>
	</div>
	<div class="clearfix"></div>


<?php include "include/footer.php"; ?>
<?php include "include/js.php"; ?>
</body>
</html>