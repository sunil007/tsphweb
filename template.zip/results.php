<?php include "include/security.php" ?>
<?php $_SESSION['pageName'] = 'index' ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php include "include/title.php"; ?>
	<?php include "include/css.php"; ?>
</head>
	
<body>
	<?php include "include/topNav.php"; ?>
		

	<!-- banner -->
	<div class="banner-silder">
		<div id="JiSlider" class="jislider">
			<ul>
				<li>
					<div class="w3layouts-banner-top3">

						<div class="container">
							<div class="agileits-banner-info">
							</div>	
						</div>
					</div>
				</li>
				<li>
					<div class="w3layouts-banner-top w3layouts-banner-top4">
					<div class="container">
							<div class="agileits-banner-info">
							</div>	
						</div>
					</div>
				</li>
				<li>
					<div class="w3layouts-banner-top w3layouts-banner-top5">
						<div class="container">
							<div class="agileits-banner-info">
							</div>	
							
						</div>
					</div>
				</li>

			</ul>
		</div>
	</div>

<!-- //banner -->

	<div class="banner-bottom">
		<div class="container">
		
			<div class="services two nopadding">
				<div class="container">
					<h3 class="w3l_header w3_agileits_header">Engineering Results <span>2018</span></h3>
						
					<h3 class="w3l_header w3_agileits_header">Medical Results <span>2018</span></h3>
					
					<h3 class="w3l_header w3_agileits_header">Engineering Results <span>2019</span></h3>
						<!--2019 Eng Results-->
					<div class="col-md-3 wthree_services_grid_right">
						<img src="images/2019EngResults/Aman C..JPG" alt="" height="260px">
					</div>
					<div class="col-md-3 wthree_services_grid_right">
						<img src="images/2019EngResults/Darshan T..JPG" alt="" height="260px">
					</div>
					<div class="col-md-3 wthree_services_grid_right">
						<img src="images/2019EngResults/Hardik P..JPG" alt="" height="260px">
					</div>
					<div class="col-md- wthree_services_grid_right">
						<img src="images/2019EngResults/Isha M..JPG" alt="" height="260px">
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php include "include/footer.php"; ?>
<?php include "include/js.php"; ?>
</body>
</html>