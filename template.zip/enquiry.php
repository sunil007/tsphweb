<h3 class="w3l_header w3_agileits_header1">Enquiry <span>Form</span></h3>
<div class="w3layouts_mail_grid">
		<div class="agileits_mail_grid_right agileits_w3layouts_mail_grid_right">
		<div class="agileits_mail_grid_right1 agile_mail_grid_right1">
			<form action="#" method="post">
				<span>
					<i>Name</i>
					<input type="text" name="Name" placeholder=" " required="">
				</span>
				<span>
					<i>Mobile</i>
					<input type="tel" name="phone" pattern="[0-9]{3}[0-9]{3}[0-9]{4}" placeholder=" " required="">
				</span>
				<span>
					<i>Subject</i>
					<!--input type="text" name="Subject" placeholder=" " required=""-->
					<select id="subject" name="Subject">
						<option value="none" selected>Select</option>
						<option value="a">A</option>
						<option value="b">B</option>
						<option value="c">C</option>
					</select>
				</span>
				<input type="submit" value="SUBMIT">
			</form>
		</div>
	</div>
	
	<div class="clearfix"> </div>
</div>