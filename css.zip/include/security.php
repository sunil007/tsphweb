<?php 
    date_default_timezone_set('Asia/Kolkata');
	if(session_status() == PHP_SESSION_NONE)
	    session_start();
?>